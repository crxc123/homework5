package com.niit.demo.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.niit.demo.service.UserService;

@Controller
public class UserController {
	@Autowired UserService userService;
	
  @RequestMapping("/show")
  public String show(@RequestParam("id")int id,Map<String,String> datas) {
	  datas.put("msg",userService.userInfo(id));
	  return "/user/show"; 
  }
}
