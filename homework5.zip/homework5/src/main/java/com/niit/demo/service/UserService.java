package com.niit.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.demo.dao.UserMapping;

@Service
public class UserService {
   @Autowired UserMapping userMapping;
	public String userInfo(int id) {
		return userMapping.selectById(id).toString();
	}
}
